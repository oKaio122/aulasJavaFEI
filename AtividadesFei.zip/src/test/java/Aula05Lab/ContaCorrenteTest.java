package Aula05Lab;

import static org.junit.jupiter.api.Assertions.*;

class ContaCorrenteTest {

    @org.junit.jupiter.api.Test
    void sacar() {
    }

    @org.junit.jupiter.api.Test
    void depositar() {
    }

    @org.junit.jupiter.api.Test
    void getSaldo() {
    }

    @org.junit.jupiter.api.Test
    void setSaldo() {
    }

    @org.junit.jupiter.api.Test
    void testToString() {
    }
}